Author: John San Diego
COS 460 Project 2
 Bouncing Ball With Gravity
Brief: create a ball and world for the ball to bounce in. Have a slider to control its speed and force. Create a goal for the user to beat.
Bugs: Could not finish implementing the goal system. Ball jitters once it loses velocity over time.